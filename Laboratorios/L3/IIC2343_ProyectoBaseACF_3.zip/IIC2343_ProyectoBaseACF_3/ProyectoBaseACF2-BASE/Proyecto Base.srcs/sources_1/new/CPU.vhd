library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.std_logic_unsigned.all;
use IEEE.numeric_std.all;


entity CPU is
    Port (
           clock : in STD_LOGIC;
           clear : in STD_LOGIC;
           ram_address : out STD_LOGIC_VECTOR (11 downto 0);
           ram_datain : out STD_LOGIC_VECTOR (15 downto 0);
           ram_dataout : in STD_LOGIC_VECTOR (15 downto 0);
           ram_write : out STD_LOGIC;
           rom_address : out STD_LOGIC_VECTOR (11 downto 0);
           rom_dataout : in STD_LOGIC_VECTOR (35 downto 0);
           dis : out STD_LOGIC_VECTOR (15 downto 0));
end CPU;

architecture Behavioral of CPU is

component Reg -- No Tocar
    Port (
        clock       : in    std_logic;
        clear       : in    std_logic;
        load        : in    std_logic;
        up          : in    std_logic;
        down        : in    std_logic;
        datain      : in    std_logic_vector (15 downto 0);
        dataout     : out   std_logic_vector (15 downto 0)
          );
    end component;

component ALU -- No Tocar
    Port ( 
        a           : in    std_logic_vector (15 downto 0);
        b           : in    std_logic_vector (15 downto 0);
        sop         : in    std_logic_vector (2 downto 0);
        c           : out   std_logic;
        z           : out   std_logic;
        n           : out   std_logic;
        result      : out   std_logic_vector (15 downto 0)
          );
    end component;

component CU  -- No Tocar
    Port (  
        op_code         : in   std_logic_vector (19 downto 0);
        sel_a           : out  std_logic_vector (1 downto 0);
        sel_b           : out  std_logic_vector (1 downto 0);
        load_a          : out  std_logic;
        load_b          : out  std_logic;
        ram_write       : out  std_logic;
        sel_op          : out  std_logic_vector (2 downto 0)
          );
    end component;
    

begin


rom_address <= "000000000000"; -- Corregir
ram_address <= "000000000000"; -- Corregir
ram_datain <= "0000000000000000"; -- Corregir
dis(15 downto 8)<= "00000000";
dis(7 downto 0) <= "00000000";
                


end Behavioral;

