
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity CU is
    Port (
            op_code         : in   std_logic_vector (19 downto 0);
            sel_a           : out  std_logic_vector (1 downto 0);
            sel_b           : out  std_logic_vector (1 downto 0);
            load_a          : out  std_logic;
            load_b          : out  std_logic;
            ram_write       : out  std_logic;
            sel_op         : out  std_logic_vector (2 downto 0)
          );
end CU;

architecture Behavioral of CU is

signal conditional : std_logic;

begin
                  
end Behavioral;