library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.std_logic_unsigned.all;

entity Reg is
    Port ( clock    : in  std_logic;                        -- Se�al del clock (reducido).
           load     : in  std_logic;                        -- Se�al de carga.
           datain   : in  std_logic_vector (7 downto 0);   -- Se�ales de entrada de datos.
           dataout  : out std_logic_vector (7 downto 0));  -- Se�ales de salida de datos.
end Reg;

architecture Behavioral of Reg is


begin


            
end Behavioral;
